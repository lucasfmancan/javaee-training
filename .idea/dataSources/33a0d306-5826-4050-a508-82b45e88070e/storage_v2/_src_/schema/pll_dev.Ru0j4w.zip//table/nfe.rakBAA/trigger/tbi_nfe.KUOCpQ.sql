create definer = root@`%` trigger tbi_nfe
    before INSERT
    on nfe
    for each row
BEGIN
	DECLARE i INTEGER;

    SELECT id_empresa INTO @i FROM nfe
    WHERE empresa_id = NEW.empresa_id
    ORDER BY id DESC LIMIT 1;

	SET NEW.id_empresa = COALESCE(@i, 0) + 1;
END;

