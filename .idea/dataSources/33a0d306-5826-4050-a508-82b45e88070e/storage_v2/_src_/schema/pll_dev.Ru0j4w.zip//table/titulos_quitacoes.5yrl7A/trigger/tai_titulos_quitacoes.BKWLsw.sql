create definer = soft360@`%` trigger tai_titulos_quitacoes
    after INSERT
    on titulos_quitacoes
    for each row
BEGIN
    DECLARE w_valor_pago DECIMAL(13, 2);
    DECLARE w_valor DECIMAL(13, 2);
    DECLARE w_quitado BOOLEAN;

    SELECT
      COALESCE(valor_pago, 0),
      valor
    INTO @w_valor_pago, @w_valor
    FROM titulos
    WHERE id = NEW.titulo_id;

    SET @w_valor_pago := @w_valor_pago + NEW.valor;

    IF @w_valor_pago > @w_valor
    THEN
      SET @w_valor_pago := @w_valor;
    END IF;

    IF @w_valor_pago = @w_valor
    THEN
      SET @w_quitado := true;
    ELSE
      SET @w_quitado := false;
    END IF;

    UPDATE titulos
    set valor_pago = @w_valor_pago, quitado = @w_quitado
    WHERE id = NEW.titulo_id;
  END;

