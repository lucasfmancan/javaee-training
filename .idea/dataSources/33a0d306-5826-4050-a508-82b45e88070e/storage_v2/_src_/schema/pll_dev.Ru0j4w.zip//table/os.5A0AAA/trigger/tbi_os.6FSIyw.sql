create definer = soft360@`%` trigger tbi_os
    before INSERT
    on os
    for each row
BEGIN
   DECLARE i MEDIUMTEXT;
	DECLARE prefixo VARCHAR(20);

    SELECT prefixo_id_empresa INTO @prefixo
            from servicos s 
            where s.id = NEW.servico_id;
    
    IF(@prefixo IS NULL) THEN
    
	SELECT o.id_empresa INTO @i  FROM os o
    JOIN servicos s on s.id = o.servico_id
    WHERE o.empresa_id = NEW.empresa_id
    AND s.prefixo_id_empresa is null
    ORDER BY o.id DESC LIMIT 1;

    SET @i = COALESCE(@i, 0) + 1;
    
    ELSE
            
	  SELECT CONCAT(@prefixo,DATE_FORMAT(NOW(),"%Y%m%d-"), lpad(coalesce(count(*), 0) + 1, 4, 0 )) as 'id_empresa' INTO @i
			from os os
            where os.servico_id = NEW.servico_id
            and os.inicio like CONCAT(DATE_FORMAT(NOW(), "%Y-%m-%d"), '%');
		
	END IF;

       SET NEW.id_empresa = @i;
END;

