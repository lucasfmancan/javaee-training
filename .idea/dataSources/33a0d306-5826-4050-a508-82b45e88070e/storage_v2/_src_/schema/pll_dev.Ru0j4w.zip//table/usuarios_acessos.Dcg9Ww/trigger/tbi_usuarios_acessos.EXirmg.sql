create definer = `lucas.mancan`@`%` trigger tbi_usuarios_acessos
    after INSERT
    on usuarios_acessos
    for each row
BEGIN
	
	DECLARE numErros INT; 
    
	SET numErros = (SELECT acessos_quantidade from usuarios where id = NEW.usuario_id);
    
	IF(numErros > 4) THEN 
		UPDATE pessoas set ativo = 0 where id = (SELECT pessoa_id from usuarios where id = NEW.usuario_id);
    END IF;
END;

