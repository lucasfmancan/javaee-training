create definer = `lucas.mancan`@`%` trigger tbi_contas_planos
    before INSERT
    on contas_planos
    for each row
BEGIN
 DECLARE i INTEGER;

    IF (NEW.id_empresa IS NULL)
    THEN
      SELECT id_empresa
      INTO @i
      FROM contas_planos
      WHERE empresa_id = NEW.empresa_id
      ORDER BY id DESC
      LIMIT 1;

      SET NEW.id_empresa = COALESCE(@i, 0) + 1;

    end if;
END;

