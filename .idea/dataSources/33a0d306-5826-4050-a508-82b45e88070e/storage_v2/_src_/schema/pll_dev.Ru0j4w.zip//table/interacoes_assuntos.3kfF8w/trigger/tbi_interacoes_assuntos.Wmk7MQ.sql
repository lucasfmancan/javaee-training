create definer = root@`%` trigger tbi_interacoes_assuntos
    before INSERT
    on interacoes_assuntos
    for each row
BEGIN
DECLARE i INTEGER;

SELECT id_empresa
INTO @i
FROM interacoes_assuntos
WHERE servico_id = NEW.servico_id
ORDER BY id DESC
LIMIT 1;

SET NEW.id_empresa = COALESCE(@i, 0) + 1;
END;

