create definer = root@`%` trigger tau_titulos_cobrancas
    after UPDATE
    on titulos_cobrancas
    for each row
BEGIN
    DECLARE _titulo_valor NUMERIC(13, 2);
    DECLARE _pagto_valor_total NUMERIC(13, 2) DEFAULT 0;

    SELECT t.valor
    INTO _titulo_valor
    FROM titulos t
    WHERE t.id = NEW.titulo_id;

    SELECT SUM(COALESCE(tc.pagto_valor, 0))
    INTO _pagto_valor_total
    FROM titulos_cobrancas tc
    WHERE tc.titulo_id = NEW.titulo_id;

    IF (_pagto_valor_total >= _titulo_valor)
    THEN
      UPDATE titulos
      SET status = 'PAG'
      WHERE id = NEW.titulo_id;
    END IF;
  END;

