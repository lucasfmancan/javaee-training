create
    definer = `lucas.mancan`@`%` function f_atualizar_itens_att() returns int
begin
DECLARE _item_id_empresa INT;
DECLARE _descricao VARCHAR(255);
DECLARE _descricao_abreviada VARCHAR(255);
DECLARE _sku VARCHAR(255);
DECLARE _sku_antigo VARCHAR(255);
DECLARE _sku_id INT;
DECLARE _id INT;
DECLARE _item_id INT;
DECLARE _sku_antigo_id INT;


    DECLARE _cur_done INTEGER DEFAULT FALSE;
    DECLARE _cur CURSOR FOR SELECT   id, 
							item_id_empresa,
							descricao,
							descricao_abreviada,
							sku_antigo,
							sku
								FROM tmp_alt;
                                   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET _cur_done = TRUE;

    OPEN _cur;

    read_loop: LOOP
        FETCH _cur INTO _id, 
						_item_id_empresa,
						_descricao,
						_descricao_abreviada,
						_sku_antigo,
						_sku;
        IF _cur_done THEN
            LEAVE read_loop;
        END IF;
        
		SET _sku_antigo_id = (SELECT DISTINCT s.id from skus s join itens i on i.id = s.item_id where i.empresa_id = 1 and s.sku = trim(_sku_antigo) limit 1);
        		
		SET _sku_id = (SELECT s.id from skus s join itens i on i.id = s.item_id where i.empresa_id = 1 and s.sku <> trim(_sku_antigo) limit 1);

		if(_sku_id IS NOT NULL) THEN
        
        UPDATE pedidos_itens set sku_id = _sku_id where sku_id = _sku_antigo_id;
        
        DELETE FROM skus where id =_sku_antigo_id;
        
        END IF;

    END LOOP;

    CLOSE _cur;
    
    RETURN (select COUNT(*) from tmp_alt where inserido = 0)
;
end;

