create
    definer = `lucas.mancan`@`%` function f_replace_sku() returns int
begin
DECLARE _id INT;
DECLARE _item_antigo INT;
DECLARE _item_novo INT;
DECLARE _item_id_novo INT;
DECLARE _item_id_antigo INT;
DECLARE _descricao VARCHAR(255);
DECLARE _model_number VARCHAR(255);
DECLARE _descricao_abreviada VARCHAR(255);
DECLARE _fabricante VARCHAR(255);
DECLARE _modelo VARCHAR(255);
DECLARE _cor VARCHAR(255);
DECLARE _sku VARCHAR(255);
DECLARE _item_antigo_id INT;
DECLARE _item_novo_id INT;
DECLARE _sku_id INT;

    DECLARE _cur_done INTEGER DEFAULT FALSE;
    DECLARE _cur CURSOR FOR SELECT  
								id,
								item_antigo,
								item_novo,
								item_id_novo,
								item_id_antigo,
								descricao,
								model_number,
								descricao_abreviada,
								fabricante,
								modelo,
								cor,
								sku
								FROM tmp;
                                   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET _cur_done = TRUE;

    OPEN _cur;

    read_loop: LOOP
        FETCH _cur INTO _id,
		_item_antigo,
		_item_novo,
		_item_id_novo,
		_item_id_antigo,
		_descricao,
		_model_number,
		_descricao_abreviada,
		_fabricante,
		_modelo,
		_cor,
		_sku;
        IF _cur_done THEN
            LEAVE read_loop;
        END IF;
        
		SET _item_antigo_id = (SELECT DISTINCT id from itens where id_empresa = _item_antigo and empresa_id = 1);
		SET _item_novo_id = (SELECT DISTINCT id from itens where id_empresa = _item_novo and empresa_id = 1);
        
		update tmp set item_id_antigo = _item_antigo_id where id = _id;
         
		if(_item_novo_id IS NOT NULL) THEN
        
        		update tmp set item_id_novo = _item_novo_id where id = _id;

                SET _sku_id = (SELECT id from skus where item_id = _item_novo_id limit 1);

                update pedidos_itens i
				join skus s on s.id = i.sku_id
				join itens i2 on i2.id = s.item_id
				set i.sku_id = _sku_id
				where i2.id = _item_antigo_id;
                
                
                update servicos_itens it
				join skus s on s.id = it.sku_id
				join itens i2 on i2.id = s.item_id
				set it.sku_id = _sku_id
				where i2.id = _item_antigo_id;
                
                update os set item_id = _item_novo_id where item_id = _item_antigo_id;
				
				DELETE from itens where id = _item_antigo_id;
				
			update tmp set updated = true where id = _id;
		else

		update os set item_id = null where item_id = _item_antigo_id;

			DELETE it from servicos_itens it
				join skus s on s.id = it.sku_id
				join itens i2 on i2.id = s.item_id
				where i2.id = _item_antigo_id;

			DELETE i from pedidos_itens i
				join skus s on s.id = i.sku_id
				join itens i2 on i2.id = s.item_id
				where i2.id = _item_antigo_id;
				
			DELETE from itens where id = _item_antigo_id;

			update tmp set deleted = true where id = _id;
                
		END IF;
    END LOOP;

    CLOSE _cur;
    
    RETURN (1);
end;

