create definer = root@`%` trigger tbi_estoques_codigos_lancamentos
    before INSERT
    on estoques_codigos_lancamentos
    for each row
BEGIN
    DECLARE _id INTEGER;
    DECLARE _estoque_id INTEGER;
    DECLARE _sku_id INTEGER;
    DECLARE _lcto_data TIMESTAMP DEFAULT NULL;
    DECLARE _lcto_fisico NUMERIC(12, 3) DEFAULT 0;
    DECLARE _lcto_virtual NUMERIC(12, 3) DEFAULT 0;

    SELECT
      el.id,
      el.estoque_id,
      el.sku_id,
      el.lcto_data,
      el.lcto_fisico,
      el.lcto_virtual
    INTO _id, _estoque_id, _sku_id, _lcto_data, _lcto_fisico, _lcto_virtual
    FROM estoques_lancamentos el
    WHERE id = NEW.lcto_id
    ORDER BY el.id DESC
    LIMIT 1;

    IF (NOT (EXISTS(SELECT 1
                    FROM estoques_codigos_saldos
                    WHERE estoque_id = _estoque_id AND sku_id = _sku_id AND
                          tipo_id = NEW.tipo_id AND codigo = NEW.codigo)))
    THEN
      INSERT INTO estoques_codigos_saldos (estoque_id, sku_id, tipo_id, codigo, ultimo_lcto, saldo_fisico, saldo_virtual)
      VALUES (_estoque_id, _sku_id, NEW.tipo_id, NEW.codigo, _lcto_data, 0, 0);
    END IF;

    UPDATE estoques_codigos_saldos
    SET
      ultimo_lcto   = _lcto_data,
      saldo_fisico  = saldo_fisico + _lcto_fisico,
      saldo_virtual = saldo_virtual + _lcto_virtual
    WHERE estoque_id = _estoque_id AND sku_id = _sku_id AND
          tipo_id = NEW.tipo_id AND codigo = NEW.codigo;
  END;

