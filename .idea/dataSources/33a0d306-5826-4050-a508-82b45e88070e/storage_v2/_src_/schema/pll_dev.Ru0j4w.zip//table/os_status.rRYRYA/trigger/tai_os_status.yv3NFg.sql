create definer = root@`%` trigger tai_os_status
    after INSERT
    on os_status
    for each row
BEGIN
    UPDATE os
    SET status_id = NEW.id
    WHERE id = NEW.os_id;
  END;

