create definer = root@`%` trigger tbi_estoques_lancamentos
    before INSERT
    on estoques_lancamentos
    for each row
BEGIN
    DECLARE _id INTEGER;
    DECLARE _saldo_fisico NUMERIC(12, 3) DEFAULT 0;
    DECLARE _saldo_virtual NUMERIC(12, 3) DEFAULT 0;

    SELECT
      id,
      saldo_fisico,
      saldo_virtual
    INTO _id, _saldo_fisico, _saldo_virtual
    FROM estoques_lancamentos
    WHERE estoque_id = NEW.estoque_id AND sku_id = NEW.sku_id
    ORDER BY id DESC
    LIMIT 1;

    IF _id IS NULL
    THEN
      SET _saldo_fisico = 0;
      SET _saldo_virtual = 0;
    END IF;

    SET NEW.saldo_fisico = _saldo_fisico + NEW.lcto_fisico;
    SET NEW.saldo_virtual = _saldo_virtual + NEW.lcto_virtual;

    IF (NOT (EXISTS(SELECT 1
                    FROM estoques_saldos
                    WHERE estoque_id = NEW.estoque_id AND
                          sku_id = NEW.sku_id)))
    THEN
      INSERT INTO estoques_saldos (ultimo_lcto, estoque_id, sku_id, saldo_fisico, saldo_virtual)
      VALUES (NEW.lcto_data, NEW.estoque_id, NEW.sku_id, 0, 0);
    END IF;

    SET NEW.observacoes = CONCAT(COALESCE(NEW.observacoes, ''), '*');

    UPDATE estoques_saldos
    SET
      ultimo_lcto   = NEW.lcto_data,
      saldo_fisico  = NEW.saldo_fisico,
      saldo_virtual = NEW.saldo_virtual
    WHERE estoque_id = NEW.estoque_id AND sku_id = NEW.sku_id;
  END;

