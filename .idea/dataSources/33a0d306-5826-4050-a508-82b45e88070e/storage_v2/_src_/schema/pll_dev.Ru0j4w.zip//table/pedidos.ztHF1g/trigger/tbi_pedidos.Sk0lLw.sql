create definer = root@`%` trigger tbi_pedidos
    before INSERT
    on pedidos
    for each row
BEGIN
    DECLARE i INTEGER;

    IF (NEW.id_empresa IS NULL)
    THEN
      SELECT id_empresa
      INTO @i
      FROM pedidos
      WHERE empresa_id = NEW.empresa_id
      ORDER BY id DESC
      LIMIT 1;

      SET NEW.id_empresa = COALESCE(@i, 0) + 1;
    END IF;
  END;

