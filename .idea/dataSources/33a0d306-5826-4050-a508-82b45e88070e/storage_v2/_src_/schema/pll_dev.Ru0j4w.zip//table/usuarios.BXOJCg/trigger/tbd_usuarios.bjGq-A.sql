create definer = root@`%` trigger tbd_usuarios
    before DELETE
    on usuarios
    for each row
BEGIN
    IF (SELECT 1
        FROM empresas
        WHERE pessoa_id = OLD.id)
    THEN
      SIGNAL SQLSTATE '45000'
      SET MESSAGE_TEXT = 'NÃO é possível excluir o usuário principal da conta.';
    END IF;
  END;

