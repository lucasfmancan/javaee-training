create definer = soft360@`%` trigger tai_os_situacoes
    after INSERT
    on os_situacoes
    for each row
BEGIN
UPDATE os
    SET situacao_id = NEW.id
    WHERE id = NEW.os_id;
END;

