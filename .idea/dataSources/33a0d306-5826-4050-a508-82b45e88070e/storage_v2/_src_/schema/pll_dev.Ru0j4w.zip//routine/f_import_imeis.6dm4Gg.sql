create
    definer = `lucas.mancan`@`%` function f_import_imeis() returns int
begin
	DECLARE _id int;
	DECLARE _sku varchar(255);
    DECLARE _imei1 varchar(255);
	DECLARE _imei2 varchar(255);
	DECLARE _sku_id INT;
	DECLARE _lcto_id INT;

    DECLARE _cur_done INTEGER DEFAULT FALSE;
    DECLARE _cur CURSOR FOR SELECT id,
									sku,
									imei1,
									imei2
									FROM tmp;
                                   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET _cur_done = TRUE;

    OPEN _cur;

    read_loop: LOOP
        FETCH _cur INTO _id,
						_sku,
                        _imei1,
                        _imei2;
					
        IF _cur_done THEN
            LEAVE read_loop;
        END IF;

		-- 
        SET _sku_id = (SELECT s.id from skus s join itens i on i.id = s.item_id where i.empresa_id = 1 and trim(s.sku) = trim(_sku) limit 1);
	
        IF(_sku_id is not null ) THEN
		INSERT INTO estoques_lancamentos(lcto_data, estoque_id, sku_id, lcto_fisico,lcto_virtual, observacoes) VALUES (now(), 1, _sku_id, 1, 1, '*');
		set _lcto_id = LAST_INSERT_ID(); 
		INSERT INTO estoques_codigos_lancamentos(lcto_id, tipo_id, codigo) VALUES (_lcto_id, 2, _imei1);
		INSERT INTO estoques_codigos_lancamentos(lcto_id, tipo_id, codigo) VALUES (_lcto_id, 2, _imei2);
        update tmp set inserido = true where id = _id;
		END IF;
    END LOOP;

    CLOSE _cur;
    
    RETURN 1;
end;

