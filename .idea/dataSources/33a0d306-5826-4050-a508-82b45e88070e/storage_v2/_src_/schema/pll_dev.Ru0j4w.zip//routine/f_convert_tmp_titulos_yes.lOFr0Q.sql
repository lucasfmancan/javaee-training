create
    definer = `lucas.mancan`@`%` function f_convert_tmp_titulos_yes() returns int
BEGIN

DECLARE _id_titulo INT;
DECLARE _id_titulo_recorrencia INT;
DECLARE _emissao VARCHAR(60);
DECLARE _vencimento VARCHAR(255);
DECLARE _pagamento VARCHAR(255);
DECLARE _conta_plano VARCHAR(255);
DECLARE _valor VARCHAR(255);
DECLARE _valor_pago VARCHAR(255);
DECLARE _pessoa VARCHAR(255);
DECLARE _cod_conta_plano VARCHAR(255);

DECLARE _cur_done INTEGER DEFAULT FALSE;
DECLARE _cur CURSOR FOR SELECT emissao, vencimento, pagamento, conta_plano_7, valor, valor_pago, pessoa, cod_conta_plano FROM tmp_titulos_yes;
                                   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET _cur_done = TRUE;

    OPEN _cur;

    read_loop: LOOP
        FETCH _cur INTO _emissao,
          _vencimento,
		_pagamento,
		_conta_plano,
		_valor,
		_valor_pago,
		_pessoa,
		_cod_conta_plano;
                        
        IF _cur_done THEN
            LEAVE read_loop;
        END IF;

        IF (SELECT passivo FROM contas_planos WHERE cod_conta_plano LIKE _cod_conta_plano) THEN
            
            INSERT INTO titulos (
                    pessoa_id, 
                    tipo_id, 
                    pedido_id, 
                    emissao, 
                    vencimento, 
                    numero, 
                    serie, 
                    valor, 
                    observacao, 
                    nfe_id, 
                    empresa_id, 
                    id_empresa, 
                    STATUS, 
                    centro_custo_id, 
                    pagamento_valor, 
                    quitado, 
                    usuario_id, 
                    lancamento_data, 
                    lancamento_usuario_id,
                    pagamento_usuario_id,
                    pagamento_data,
                    cancelamento_usuario_id,
                    cancelamento_data,
                    recorrencia_numero,
                    recorrencia_id
                )
         
            VALUES (
                    (SELECT id FROM pessoas WHERE empresa_id = 1 AND nome LIKE CONCAT('%', _pessoa, '%') limit 1), 
                    "PAG", 
                    NULL,
                    (SELECT STR_TO_DATE(_emissao,'%Y-m%-%d %H:%d:%s')),
                    (SELECT STR_TO_DATE(_vencimento,'%Y-m%-%d %H:%d:%s')),
                    NULL,
                    NULL,
                    _valor,
                    NULL,
                    NULL,
                    1,
                    NULL,
                    "PAG",
                    NULL,
                    _valor_pago,
                    1,
                    1,
                    (SELECT STR_TO_DATE(_emissao,'%Y-m%-%d %H:%d:%s')),
                    1,
                    1,
                    (SELECT STR_TO_DATE(_pagamento,'%Y-m%-%d %H:%d:%s')),
                    NULL,
                    NULL,
                    1,
                    NULL
                );

        SET _id_titulo = LAST_INSERT_ID();
    
    INSERT INTO titulos_recorrencias (
            emissao, 
            conta_plano_id, 
            custo_centro_id, 
            valor, 
            quantidade, 
            recorrente, 
            sistemico
        ) 
        
        VALUES (
            (SELECT STR_TO_DATE(_emissao,'%d/%m/%Y')), 
            (SELECT id FROM contas_planos WHERE empresa_id = 1 AND cod_conta_plano LIKE CONCAT('%',_cod_conta_plano,'%') limit 1), 
            NULL, 
            _valor, 
            1,
            0,
            0
        );
    
    SET _id_titulo_recorrencia = LAST_INSERT_ID();

UPDATE titulos 
SET 
    recorrencia_id = _id_titulo_recorrencia
WHERE
    id = _id_titulo;
    
    INSERT INTO contas_lancamentos (
            conta_id, 
            descricao, 
            lcto_data, 
            valor, 
            usuario_id, 
            criacao, 
            alteracao, 
            acrescimos, 
            descontos, 
            titulo_id, 
            saldo
        ) 
        
        VALUES (
                1, 
                NULL, 
                (SELECT STR_TO_DATE(_pagamento,'%d/%m/%Y')), 
                _valor_pago, 
                1, 
				(SELECT STR_TO_DATE(_emissao,'%d/%m/%Y')),
                NULL, 
                NULL, 
                NULL,
                _id_titulo, 
                NULL
            );

            ELSE 

            INSERT INTO titulos (
                                pessoa_id, 
                                tipo_id, 
                                pedido_id, 
                                emissao, 
                                vencimento, 
                                numero, 
                                serie, 
                                valor, 
                                observacao, 
                                nfe_id, 
                                empresa_id, 
                                id_empresa, 
                                status, 
                                centro_custo_id, 
                                pagamento_valor, 
                                quitado, 
                                usuario_id, 
                                lancamento_data, 
                                lancamento_usuario_id,
                                pagamento_usuario_id,
                                pagamento_data,
                                cancelamento_usuario_id,
                                cancelamento_data,
                                recorrencia_numero,
                                recorrencia_id
                            )
                    
                        VALUES (
                                (SELECT id FROM pessoas WHERE empresa_id = 1 AND nome LIKE CONCAT('%',_pessoa,'%') limit 1), 
                                'REC', 
                                NULL,
                                (SELECT STR_TO_DATE(_emissao,'%d/%m/%Y')),
                                (SELECT STR_TO_DATE(_vencimento,'%d/%m/%Y')),
                                NULL,
                                NULL,
                                _valor,
                                NULL,
                                NULL,
                                1,
                                NULL,
                                'PAG',
                                NULL,
                                _valor_pago,
                                1,
                                1,
                                (SELECT STR_TO_DATE(_emissao,'%d/%m/%Y')),
                                1,
                                1,
                                (SELECT STR_TO_DATE(_pagamento,'%d/%m/%Y')),
                                NULL,
                                NULL,
                                1,
                                NULL
                            );

                    SET _id_titulo = LAST_INSERT_ID();
                
                INSERT INTO titulos_recorrencias (
                        emissao, 
                        conta_plano_id, 
                        custo_centro_id, 
                        valor, 
                        quantidade, 
                        recorrente, 
                        sistemico
                    ) 
                    
                    VALUES (
                        (SELECT STR_TO_DATE(_emissao,'%d/%m/%Y')), 
                        (SELECT id FROM contas_planos WHERE empresa_id = 1 AND cod_conta_plano LIKE CONCAT('%',_cod_conta_plano,'%') limit 1), 
                        NULL, 
                        _valor, 
                        1,
                        0,
                        0
                    );
                
                SET _id_titulo_recorrencia = LAST_INSERT_ID();

UPDATE titulos 
SET 
    recorrencia_id = _id_titulo_recorrencia
WHERE
    id = _id_titulo;
                
                INSERT INTO contas_lancamentos (
                        conta_id, 
                        descricao, 
                        lcto_data, 
                        valor, 
                        usuario_id, 
                        criacao, 
                        alteracao, 
                        acrescimos, 
                        descontos, 
                        titulo_id, 
                        saldo
                    ) 
                    
                    VALUES (
                            1, 
                            NULL, 
                            (SELECT STR_TO_DATE(_emissao,'%d/%m/%Y')), 
                            _valor_pago, 
                            1, 
                            (SELECT STR_TO_DATE(_emissao,'%d/%m/%Y')), 
                            NULL, 
                            NULL, 
                            NULL,
                            _id_titulo, NULL);

        END IF;

    END LOOP;

    CLOSE _cur;
    
    RETURN (SELECT 1);
END;

