create definer = `lucas.mancan`@`%` trigger tbi_skus_precos
    before INSERT
    on precos
    for each row
BEGIN
    IF (NOT (EXISTS(SELECT 1
                    FROM skus_precos
                    WHERE tabela_id = NEW.tabela_id AND
                          sku_id = NEW.sku_id)))
    THEN

      INSERT INTO skus_precos (tabela_id, sku_id, inicio, fim,preco,  promocional)
      VALUES (NEW.tabela_id, NEW.sku_id, NEW.inicio, NEW.fim, NEW.preco, NEW.promocional);

      ELSE
        UPDATE skus_precos
        SET
          inicio = NEW.inicio,
          fim = NEW.fim,
          preco = NEW.preco,
          promocional = NEW.promocional,
          ultimo_lcto   = NEW.criacao
        WHERE tabela_id = NEW.tabela_id AND sku_id = NEW.sku_id;
    END IF;

  END;

