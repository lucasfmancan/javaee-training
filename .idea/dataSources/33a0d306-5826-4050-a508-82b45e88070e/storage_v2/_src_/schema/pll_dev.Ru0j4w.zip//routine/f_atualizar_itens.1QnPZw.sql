create
    definer = `lucas.mancan`@`%` function f_atualizar_itens() returns int
begin
DECLARE _item_id_empresa INT;
DECLARE _descricao VARCHAR(255);
DECLARE _descricao_abreviada VARCHAR(255);
DECLARE _sku VARCHAR(255);
DECLARE _sku_antigo VARCHAR(255);
DECLARE _sku_id INT;
DECLARE _id INT;
DECLARE _item_id INT;
DECLARE _sku_antigo_id INT;


    DECLARE _cur_done INTEGER DEFAULT FALSE;
    DECLARE _cur CURSOR FOR SELECT   id, 
							item_id_empresa,
							descricao,
							descricao_abreviada,
							sku_antigo,
							sku
								FROM tmp_alt;
                                   
    DECLARE CONTINUE HANDLER FOR NOT FOUND SET _cur_done = TRUE;

    OPEN _cur;

    read_loop: LOOP
        FETCH _cur INTO _id, 
							_item_id_empresa,
							_descricao,
							_descricao_abreviada,
							_sku_antigo,
							_sku;
        IF _cur_done THEN
            LEAVE read_loop;
        END IF;
        
	   
	   SET _item_id = (SELECT id from itens where empresa_id = 1 and id_empresa = _item_id_empresa);
        
		UPDATE itens set descricao = TRIM(_descricao), descricao_abreviada = TRIM(_descricao_abreviada) where id = _item_id;
		
		SET _sku_antigo_id = (SELECT id from skus where item_id = _item_id and sku = trim(_sku_antigo));


		IF(NOT EXISTS(SELECT id FROM skus where item_id  = _item_id and sku = TRIM(_sku))) THEN
		insert into skus (sku, item_id) VALUES (TRIM(_sku), _item_id);
        		UPDATE tmp_alt set inserido = 1 where id = _id;
        END IF;

-- 		IF(_sku_antigo_id IS NOT NULL) THEN
-- 	-- 	
-- -- 		DELETE FROM precos where sku_id = _sku_antigo_id;
-- -- 		DELETE FROM itens_composicoes where sku_id = _sku_antigo_id;
-- -- 		DELETE FROM estoques_saldos where sku_id = _sku_antigo_id;
-- -- 		DELETE FROM estoques_locais where sku_id = _sku_antigo_id;
-- -- 		DELETE FROM estoques_lancamentos where sku_id = _sku_antigo_id;
-- --         
-- -- 		DELETE FROM skus where id = _sku_antigo_id;
-- --         
-- -- 		END IF;
-- -- 		
-- 		
-- -- 		UPDATE tmp_alt set inserido = 1 where id = _id;
-- 		END IF;
--                
    END LOOP;

    CLOSE _cur;
    
    RETURN (select COUNT(*) from tmp_alt where inserido = 0)
;
end;

