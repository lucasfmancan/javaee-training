create definer = `lucas.mancan`@`%` trigger os_arquivos_situacoes_AFTER_INSERT
    after INSERT
    on os_arquivos_situacoes
    for each row
BEGIN
UPDATE os_arquivos
    SET arquivo_situacao_id = NEW.id
    WHERE id = NEW.os_arquivo_id;
END;

