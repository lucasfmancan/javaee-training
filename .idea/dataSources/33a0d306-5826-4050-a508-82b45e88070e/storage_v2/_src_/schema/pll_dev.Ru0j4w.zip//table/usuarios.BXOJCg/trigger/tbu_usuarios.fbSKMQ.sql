create definer = root@localhost trigger tbu_usuarios
    before UPDATE
    on usuarios
    for each row
BEGIN
    IF (NEW.senha IS NULL) THEN
      SET NEW.senha = OLD.senha;
    end if;
  END;

